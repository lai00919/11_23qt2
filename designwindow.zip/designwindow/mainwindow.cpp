#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUi(this);

    // 1. 建立中央文字編輯區，設為視窗主體
    textEdit = new QTextEdit(this);
    setCentralWidget(textEdit);

    // 2. 連接「檔案」功能表動作 (Signals & Slots)
    connect(actionNew,   &QAction::triggered, this, &MainWindow::onNewFile);
    connect(actionOpen,  &QAction::triggered, this, &MainWindow::onOpenFile);
    connect(actionSave,  &QAction::triggered, this, &MainWindow::onSaveFile);
    connect(actionASave, &QAction::triggered, this, &MainWindow::onSaveFile);
    connect(actionClose, &QAction::triggered, this, &MainWindow::onCloseFile);
    connect(actionQuit,  &QAction::triggered, this, &QMainWindow::close);

    // 3. 連接「編輯」功能表動作（直接綁定 QTextEdit 內建功能）
    connect(actionUndo, &QAction::triggered, textEdit, &QTextEdit::undo);
    connect(actionCuT,  &QAction::triggered, textEdit, &QTextEdit::cut);
    connect(actionCopy, &QAction::triggered, textEdit, &QTextEdit::copy);
    connect(actionAll,  &QAction::triggered, textEdit, &QTextEdit::selectAll);
}

MainWindow::~MainWindow() = default;

// 【新增】清空編輯區
void MainWindow::onNewFile()
{
    currentFile.clear();
    textEdit->clear();
    statusBar()->showMessage("已建立新文件", 3000);
}

// 【開啟】跳出檔案選擇視窗並讀取文字檔
void MainWindow::onOpenFile()
{
    QString fileName = QFileDialog::getOpenFileName(
        this, "開啟檔案", "", "文字檔 (*.txt);;所有檔案 (*.*)");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "錯誤", "無法開啟檔案：" + file.errorString());
        return;
    }

    QTextStream in(&file);
    textEdit->setPlainText(in.readAll());
    file.close();
    currentFile = fileName;
    statusBar()->showMessage("已開啟：" + fileName, 3000);
}

// 【儲存 / 另存】將文字寫入檔案
void MainWindow::onSaveFile()
{
    QString fileName = QFileDialog::getSaveFileName(
        this, "儲存檔案", currentFile, "文字檔 (*.txt);;所有檔案 (*.*)");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "錯誤", "無法儲存檔案：" + file.errorString());
        return;
    }

    QTextStream out(&file);
    out << textEdit->toPlainText();
    file.close();
    currentFile = fileName;
    statusBar()->showMessage("已儲存：" + fileName, 3000);
}

// 【關閉】清除目前內容
void MainWindow::onCloseFile()
{
    currentFile.clear();
    textEdit->clear();
    statusBar()->showMessage("已關閉檔案", 3000);
}