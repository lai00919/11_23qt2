#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include "ui_mainwindow.h"

class MainWindow : public QMainWindow,
                   public Ui_MainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void onNewFile();      // 新增
    void onOpenFile();     // 開啟
    void onSaveFile();     // 儲存
    void onCloseFile();    // 關閉

private:
    QTextEdit *textEdit;   // 中央文字編輯區（讓還原、剪下、複製、全選有作用）
    QString currentFile;   // 記錄目前開啟的檔案路徑
};
#endif // MAINWINDOW_H